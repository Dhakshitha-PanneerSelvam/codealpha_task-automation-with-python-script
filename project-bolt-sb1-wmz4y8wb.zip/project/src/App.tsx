import React, { useState, useCallback } from 'react';
import { Camera, Loader, AlertCircle, Brain } from 'lucide-react';
import { useCamera } from './hooks/useCamera';
import { useObjectDetection } from './hooks/useObjectDetection';
import VideoCanvas from './components/VideoCanvas';
import PerformanceMetrics from './components/PerformanceMetrics';
import Controls from './components/Controls';
import ObjectList from './components/ObjectList';

function App() {
  const [confidence, setConfidence] = useState(0.5);
  const {
    videoRef,
    isStreaming,
    error: cameraError,
    devices,
    currentDevice,
    startCamera,
    stopCamera,
    switchCamera,
  } = useCamera();

  const {
    isLoading: modelLoading,
    isDetecting,
    trackedObjects,
    metrics,
    startDetection,
    stopDetection,
  } = useObjectDetection();

  const handleToggleDetection = useCallback(() => {
    if (!videoRef.current) return;

    if (isDetecting) {
      stopDetection();
    } else {
      // Create a canvas for detection processing
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      
      startDetection(videoRef.current, canvas, confidence);
    }
  }, [isDetecting, startDetection, stopDetection, confidence, videoRef]);

  const handleExportData = useCallback(() => {
    const data = {
      timestamp: new Date().toISOString(),
      metrics,
      objects: trackedObjects.map(obj => ({
        trackId: obj.trackId,
        class: obj.class,
        confidence: obj.confidence,
        position: obj.center,
        velocity: obj.velocity,
        trail: obj.trail,
      })),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json',
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `object-tracking-data-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [metrics, trackedObjects]);

  if (modelLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
        <div className="text-center">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin mx-auto mb-4" />
            <Brain className="w-8 h-8 text-cyan-400 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Loading AI Model</h2>
          <p className="text-gray-400">Initializing TensorFlow.js and COCO-SSD...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black text-white">
      {/* Header */}
      <header className="bg-gray-800/50 backdrop-blur-lg border-b border-gray-700/50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg">
              <Camera className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                Object Detection & Tracking
              </h1>
              <p className="text-sm text-gray-400">Real-time AI-powered vision system</p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        {cameraError && (
          <div className="mb-6 bg-red-900/50 border border-red-500/50 rounded-lg p-4 flex items-center space-x-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <h3 className="font-medium text-red-300">Camera Error</h3>
              <p className="text-sm text-red-200">{cameraError}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Video Feed */}
          <div className="lg:col-span-2">
            <div className="bg-gray-800/50 backdrop-blur-lg rounded-lg p-6 border border-gray-700/50">
              <h2 className="text-xl font-semibold mb-4 flex items-center space-x-2">
                <Camera className="w-5 h-5 text-cyan-400" />
                <span>Live Video Feed</span>
                {isStreaming && (
                  <div className="flex items-center space-x-1 ml-auto">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-sm text-green-400">Live</span>
                  </div>
                )}
              </h2>

              <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
                {isStreaming ? (
                  <>
                    <video
                      ref={videoRef}
                      autoPlay
                      muted
                      playsInline
                      className="w-full h-full object-cover"
                    />
                    <VideoCanvas
                      video={videoRef.current}
                      trackedObjects={trackedObjects}
                      isDetecting={isDetecting}
                    />
                  </>
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <Camera className="w-16 h-16 mx-auto mb-4 text-gray-600" />
                      <p className="text-gray-400">
                        {modelLoading ? 'Loading...' : 'Camera not available'}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="mt-6">
              <PerformanceMetrics metrics={metrics} isDetecting={isDetecting} />
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Controls */}
            <Controls
              isDetecting={isDetecting}
              isLoading={modelLoading}
              confidence={confidence}
              onToggleDetection={handleToggleDetection}
              onConfidenceChange={setConfidence}
              onExportData={handleExportData}
              devices={devices}
              currentDevice={currentDevice}
              onSwitchCamera={switchCamera}
            />

            {/* Object List */}
            <ObjectList trackedObjects={trackedObjects} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;