import React from 'react';
import { Play, Pause, Camera, Settings, Download } from 'lucide-react';

interface ControlsProps {
  isDetecting: boolean;
  isLoading: boolean;
  confidence: number;
  onToggleDetection: () => void;
  onConfidenceChange: (value: number) => void;
  onExportData: () => void;
  devices: MediaDeviceInfo[];
  currentDevice: string;
  onSwitchCamera: (deviceId: string) => void;
}

const Controls: React.FC<ControlsProps> = ({
  isDetecting,
  isLoading,
  confidence,
  onToggleDetection,
  onConfidenceChange,
  onExportData,
  devices,
  currentDevice,
  onSwitchCamera,
}) => {
  return (
    <div className="bg-gray-800/50 backdrop-blur-lg rounded-lg p-6 border border-gray-700/50">
      <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
        <Settings className="w-5 h-5 text-cyan-400" />
        <span>Controls</span>
      </h3>
      
      <div className="space-y-4">
        {/* Detection Toggle */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-300 font-medium">Detection</span>
          <button
            onClick={onToggleDetection}
            disabled={isLoading}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
              isDetecting
                ? 'bg-red-500 hover:bg-red-600 text-white'
                : 'bg-green-500 hover:bg-green-600 text-white'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {isDetecting ? (
              <>
                <Pause className="w-4 h-4" />
                <span>Stop</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                <span>Start</span>
              </>
            )}
          </button>
        </div>

        {/* Confidence Threshold */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-300 font-medium">Confidence</span>
            <span className="text-sm text-cyan-400 font-mono">
              {Math.round(confidence * 100)}%
            </span>
          </div>
          <div className="relative">
            <input
              type="range"
              min="0.1"
              max="0.9"
              step="0.05"
              value={confidence}
              onChange={(e) => onConfidenceChange(parseFloat(e.target.value))}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
            />
          </div>
        </div>

        {/* Camera Selection */}
        {devices.length > 1 && (
          <div className="space-y-2">
            <span className="text-sm text-gray-300 font-medium">Camera</span>
            <select
              value={currentDevice}
              onChange={(e) => onSwitchCamera(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-cyan-400 focus:border-transparent"
            >
              {devices.map((device) => (
                <option key={device.deviceId} value={device.deviceId}>
                  {device.label || `Camera ${device.deviceId.slice(0, 8)}`}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Export Button */}
        <button
          onClick={onExportData}
          className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-all duration-200"
        >
          <Download className="w-4 h-4" />
          <span>Export Data</span>
        </button>
      </div>
    </div>
  );
};

export default Controls;