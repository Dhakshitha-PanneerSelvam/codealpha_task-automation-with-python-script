import React from 'react';
import { Eye, Target, TrendingUp } from 'lucide-react';
import { TrackedObject } from '../types';

interface ObjectListProps {
  trackedObjects: TrackedObject[];
}

const ObjectList: React.FC<ObjectListProps> = ({ trackedObjects }) => {
  const getObjectStats = (obj: TrackedObject) => {
    const speed = Math.sqrt(obj.velocity[0] ** 2 + obj.velocity[1] ** 2);
    const age = Date.now() - (obj.timestamp - obj.trail.length * 100); // Approximate age
    
    return {
      speed: Math.round(speed * 10) / 10,
      age: Math.round(age / 1000 * 10) / 10,
      confidence: Math.round(obj.confidence * 100),
    };
  };

  if (trackedObjects.length === 0) {
    return (
      <div className="bg-gray-800/50 backdrop-blur-lg rounded-lg p-6 border border-gray-700/50">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
          <Eye className="w-5 h-5 text-cyan-400" />
          <span>Detected Objects</span>
        </h3>
        <div className="text-center text-gray-400 py-8">
          <Target className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No objects detected</p>
          <p className="text-sm mt-1">Start detection to see tracked objects</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-800/50 backdrop-blur-lg rounded-lg p-6 border border-gray-700/50">
      <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
        <Eye className="w-5 h-5 text-cyan-400" />
        <span>Detected Objects ({trackedObjects.length})</span>
      </h3>
      
      <div className="space-y-3 max-h-64 overflow-y-auto custom-scrollbar">
        {trackedObjects.map((obj) => {
          const stats = getObjectStats(obj);
          const colors = ['#00D4FF', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7'];
          const color = colors[parseInt(obj.trackId.split('_')[1]) % colors.length];

          return (
            <div
              key={obj.trackId}
              className="bg-gray-700/50 rounded-lg p-4 border border-gray-600/50 hover:border-gray-500/50 transition-colors"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: color }}
                  />
                  <span className="font-medium text-white capitalize">
                    {obj.class}
                  </span>
                </div>
                <span className="text-xs text-gray-400 font-mono">
                  {obj.trackId}
                </span>
              </div>
              
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div className="text-center">
                  <div className="text-gray-400 mb-1">Confidence</div>
                  <div className="font-bold text-green-400">
                    {stats.confidence}%
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-gray-400 mb-1">Speed</div>
                  <div className="font-bold text-blue-400 flex items-center justify-center space-x-1">
                    <TrendingUp className="w-3 h-3" />
                    <span>{stats.speed}</span>
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-gray-400 mb-1">Age</div>
                  <div className="font-bold text-purple-400">
                    {stats.age}s
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ObjectList;