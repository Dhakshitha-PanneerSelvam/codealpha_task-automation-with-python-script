import React from 'react';
import { Activity, Clock, Target, Zap } from 'lucide-react';
import { PerformanceMetrics as MetricsType } from '../types';

interface PerformanceMetricsProps {
  metrics: MetricsType;
  isDetecting: boolean;
}

const PerformanceMetrics: React.FC<PerformanceMetricsProps> = ({
  metrics,
  isDetecting,
}) => {
  const metricItems = [
    {
      icon: Activity,
      label: 'FPS',
      value: metrics.fps.toString(),
      unit: '',
      color: 'text-green-400',
    },
    {
      icon: Clock,
      label: 'Detection',
      value: metrics.detectionTime.toString(),
      unit: 'ms',
      color: 'text-blue-400',
    },
    {
      icon: Zap,
      label: 'Tracking',
      value: metrics.trackingTime.toString(),
      unit: 'ms',
      color: 'text-purple-400',
    },
    {
      icon: Target,
      label: 'Objects',
      value: metrics.objectCount.toString(),
      unit: '',
      color: 'text-orange-400',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {metricItems.map(({ icon: Icon, label, value, unit, color }) => (
        <div
          key={label}
          className="bg-gray-800/50 backdrop-blur-lg rounded-lg p-4 border border-gray-700/50"
        >
          <div className="flex items-center space-x-2 mb-2">
            <Icon className={`w-4 h-4 ${color}`} />
            <span className="text-sm text-gray-300 font-medium">{label}</span>
          </div>
          <div className="flex items-baseline space-x-1">
            <span className={`text-2xl font-bold ${color}`}>
              {isDetecting ? value : '--'}
            </span>
            {unit && (
              <span className="text-sm text-gray-400">{unit}</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default PerformanceMetrics;