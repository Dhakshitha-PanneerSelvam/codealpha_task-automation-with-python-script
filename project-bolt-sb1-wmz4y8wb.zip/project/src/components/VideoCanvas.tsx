import React, { useRef, useEffect, useCallback } from 'react';
import { TrackedObject } from '../types';

interface VideoCanvasProps {
  video: HTMLVideoElement | null;
  trackedObjects: TrackedObject[];
  isDetecting: boolean;
}

const VideoCanvas: React.FC<VideoCanvasProps> = ({
  video,
  trackedObjects,
  isDetecting,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const drawBoundingBoxes = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    
    if (!canvas || !ctx || !video) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (!isDetecting) return;

    // Set up drawing styles
    ctx.strokeStyle = '#00D4FF';
    ctx.lineWidth = 3;
    ctx.fillStyle = 'rgba(0, 212, 255, 0.1)';
    ctx.font = '14px Inter, sans-serif';

    trackedObjects.forEach((obj, index) => {
      const [x, y, width, height] = obj.bbox;
      
      // Use different colors for different objects
      const colors = ['#00D4FF', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7'];
      const color = colors[parseInt(obj.trackId.split('_')[1]) % colors.length];
      
      ctx.strokeStyle = color;
      ctx.fillStyle = color + '20';

      // Draw bounding box
      ctx.fillRect(x, y, width, height);
      ctx.strokeRect(x, y, width, height);

      // Draw trail
      if (obj.trail.length > 1) {
        ctx.strokeStyle = color + '80';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(obj.trail[0][0], obj.trail[0][1]);
        
        for (let i = 1; i < obj.trail.length; i++) {
          ctx.lineTo(obj.trail[i][0], obj.trail[i][1]);
        }
        ctx.stroke();

        // Draw trail points
        obj.trail.forEach((point, i) => {
          const alpha = (i + 1) / obj.trail.length;
          ctx.fillStyle = color + Math.floor(alpha * 255).toString(16).padStart(2, '0');
          ctx.fillRect(point[0] - 2, point[1] - 2, 4, 4);
        });
      }

      // Draw label background
      const label = `${obj.class} (${Math.round(obj.confidence * 100)}%)`;
      const textMetrics = ctx.measureText(label);
      const textWidth = textMetrics.width;
      const textHeight = 20;

      ctx.fillStyle = color;
      ctx.fillRect(x, y - textHeight - 4, textWidth + 12, textHeight + 4);

      // Draw label text
      ctx.fillStyle = '#000';
      ctx.fillText(label, x + 6, y - 8);

      // Draw track ID
      ctx.fillStyle = color + '80';
      ctx.font = '12px Inter, sans-serif';
      ctx.fillText(`ID: ${obj.trackId}`, x, y + height + 15);

      // Draw velocity indicator
      if (Math.abs(obj.velocity[0]) > 1 || Math.abs(obj.velocity[1]) > 1) {
        const centerX = x + width / 2;
        const centerY = y + height / 2;
        const velX = obj.velocity[0] * 2;
        const velY = obj.velocity[1] * 2;

        ctx.strokeStyle = '#FF6B6B';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(centerX + velX, centerY + velY);
        ctx.stroke();

        // Arrow head
        const angle = Math.atan2(velY, velX);
        const arrowLength = 8;
        ctx.beginPath();
        ctx.moveTo(centerX + velX, centerY + velY);
        ctx.lineTo(
          centerX + velX - arrowLength * Math.cos(angle - Math.PI / 6),
          centerY + velY - arrowLength * Math.sin(angle - Math.PI / 6)
        );
        ctx.moveTo(centerX + velX, centerY + velY);
        ctx.lineTo(
          centerX + velX - arrowLength * Math.cos(angle + Math.PI / 6),
          centerY + velY - arrowLength * Math.sin(angle + Math.PI / 6)
        );
        ctx.stroke();
      }
    });
  }, [video, trackedObjects, isDetecting]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas && video) {
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      
      const animate = () => {
        drawBoundingBoxes();
        requestAnimationFrame(animate);
      };
      
      const animationId = requestAnimationFrame(animate);
      
      return () => cancelAnimationFrame(animationId);
    }
  }, [video, drawBoundingBoxes]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute top-0 left-0 pointer-events-none z-10"
      style={{
        width: '100%',
        height: '100%',
        objectFit: 'cover',
      }}
    />
  );
};

export default VideoCanvas;