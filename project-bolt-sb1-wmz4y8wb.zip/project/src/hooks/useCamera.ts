import { useRef, useCallback, useState, useEffect } from 'react';

interface CameraSettings {
  width: number;
  height: number;
  facingMode: 'user' | 'environment';
}

export const useCamera = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [currentDevice, setCurrentDevice] = useState<string>('');

  const getDevices = useCallback(async () => {
    try {
      const deviceList = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = deviceList.filter(device => device.kind === 'videoinput');
      setDevices(videoDevices);
      if (videoDevices.length > 0 && !currentDevice) {
        setCurrentDevice(videoDevices[0].deviceId);
      }
    } catch (err) {
      console.error('Error getting devices:', err);
    }
  }, [currentDevice]);

  const startCamera = useCallback(async (settings: Partial<CameraSettings> = {}) => {
    try {
      setError(null);
      
      // Stop existing stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }

      const constraints: MediaStreamConstraints = {
        video: {
          width: settings.width || 640,
          height: settings.height || 480,
          facingMode: settings.facingMode || 'environment',
          deviceId: currentDevice ? { exact: currentDevice } : undefined,
        },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
          setIsStreaming(true);
        };
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to access camera';
      setError(errorMessage);
      console.error('Camera error:', err);
    }
  }, [currentDevice]);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    
    setIsStreaming(false);
  }, []);

  const switchCamera = useCallback((deviceId: string) => {
    setCurrentDevice(deviceId);
  }, []);

  useEffect(() => {
    getDevices();
    return () => {
      stopCamera();
    };
  }, [getDevices]);

  useEffect(() => {
    if (currentDevice && !isStreaming) {
      startCamera();
    }
  }, [currentDevice, startCamera, isStreaming]);

  return {
    videoRef,
    isStreaming,
    error,
    devices,
    currentDevice,
    startCamera,
    stopCamera,
    switchCamera,
  };
};