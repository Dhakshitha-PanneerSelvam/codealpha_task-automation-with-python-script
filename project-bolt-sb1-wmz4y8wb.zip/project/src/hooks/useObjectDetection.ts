import { useRef, useCallback, useEffect, useState } from 'react';
import * as tf from '@tensorflow/tfjs';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import { DetectedObject, TrackedObject, PerformanceMetrics } from '../types';

export const useObjectDetection = () => {
  const [model, setModel] = useState<cocoSsd.ObjectDetection | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDetecting, setIsDetecting] = useState(false);
  const [trackedObjects, setTrackedObjects] = useState<TrackedObject[]>([]);
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    fps: 0,
    detectionTime: 0,
    trackingTime: 0,
    objectCount: 0,
    processingTime: 0,
  });

  const animationRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);
  const frameCountRef = useRef<number>(0);
  const trackIdCounterRef = useRef<number>(0);

  const loadModel = useCallback(async () => {
    try {
      setIsLoading(true);
      await tf.ready();
      const loadedModel = await cocoSsd.load();
      setModel(loadedModel);
      setIsLoading(false);
    } catch (error) {
      console.error('Error loading model:', error);
      setIsLoading(false);
    }
  }, []);

  const calculateDistance = (center1: [number, number], center2: [number, number]): number => {
    const dx = center1[0] - center2[0];
    const dy = center1[1] - center2[1];
    return Math.sqrt(dx * dx + dy * dy);
  };

  const assignTrackIds = (detections: DetectedObject[], previousTracked: TrackedObject[]): TrackedObject[] => {
    const tracked: TrackedObject[] = [];
    const usedTrackIds = new Set<string>();
    const maxDistance = 100; // Maximum distance to consider same object

    for (const detection of detections) {
      let bestMatch: TrackedObject | null = null;
      let minDistance = Infinity;

      // Find closest previous object
      for (const prev of previousTracked) {
        if (usedTrackIds.has(prev.trackId)) continue;
        
        const distance = calculateDistance(detection.center, prev.center);
        if (distance < minDistance && distance < maxDistance && detection.class === prev.class) {
          minDistance = distance;
          bestMatch = prev;
        }
      }

      if (bestMatch) {
        // Update existing track
        const velocity: [number, number] = [
          detection.center[0] - bestMatch.center[0],
          detection.center[1] - bestMatch.center[1]
        ];

        const newTrail = [...bestMatch.trail, detection.center].slice(-10); // Keep last 10 positions

        tracked.push({
          ...detection,
          trackId: bestMatch.trackId,
          trail: newTrail,
          velocity,
          lastSeen: Date.now(),
          confidence: (bestMatch.confidence * 0.8) + (detection.score * 0.2), // Smooth confidence
        });

        usedTrackIds.add(bestMatch.trackId);
      } else {
        // Create new track
        const newTrackId = `track_${trackIdCounterRef.current++}`;
        tracked.push({
          ...detection,
          trackId: newTrackId,
          trail: [detection.center],
          velocity: [0, 0],
          lastSeen: Date.now(),
          confidence: detection.score,
        });
      }
    }

    // Keep objects that were recently seen but not detected in current frame
    const currentTime = Date.now();
    const maxAge = 1000; // 1 second

    for (const prev of previousTracked) {
      if (!usedTrackIds.has(prev.trackId) && (currentTime - prev.lastSeen) < maxAge) {
        tracked.push({
          ...prev,
          confidence: prev.confidence * 0.9, // Decrease confidence over time
        });
      }
    }

    return tracked;
  };

  const detect = useCallback(async (
    video: HTMLVideoElement,
    canvas: HTMLCanvasElement,
    confidenceThreshold: number = 0.5
  ) => {
    if (!model || !video || !canvas) return;

    const startTime = performance.now();
    
    try {
      // Perform detection
      const detectionStart = performance.now();
      const predictions = await model.detect(video);
      const detectionTime = performance.now() - detectionStart;

      // Filter by confidence and convert to our format
      const detections: DetectedObject[] = predictions
        .filter(pred => pred.score >= confidenceThreshold)
        .map((pred, index) => {
          const [x, y, width, height] = pred.bbox;
          const center: [number, number] = [x + width / 2, y + height / 2];
          
          return {
            id: `${pred.class}_${index}_${Date.now()}`,
            class: pred.class,
            score: pred.score,
            bbox: pred.bbox as [number, number, number, number],
            center,
            timestamp: Date.now(),
          };
        });

      // Update tracking
      const trackingStart = performance.now();
      setTrackedObjects(prev => assignTrackIds(detections, prev));
      const trackingTime = performance.now() - trackingStart;

      // Update metrics
      const currentTime = performance.now();
      const deltaTime = currentTime - lastTimeRef.current;
      frameCountRef.current++;

      if (deltaTime >= 1000) { // Update FPS every second
        const fps = Math.round((frameCountRef.current * 1000) / deltaTime);
        
        setMetrics({
          fps,
          detectionTime: Math.round(detectionTime),
          trackingTime: Math.round(trackingTime),
          objectCount: detections.length,
          processingTime: Math.round(currentTime - startTime),
        });

        frameCountRef.current = 0;
        lastTimeRef.current = currentTime;
      }

    } catch (error) {
      console.error('Detection error:', error);
    }
  }, [model]);

  const startDetection = useCallback((
    video: HTMLVideoElement,
    canvas: HTMLCanvasElement,
    confidenceThreshold: number = 0.5
  ) => {
    if (!model || isDetecting) return;

    setIsDetecting(true);
    lastTimeRef.current = performance.now();
    frameCountRef.current = 0;

    const detectFrame = async () => {
      await detect(video, canvas, confidenceThreshold);
      if (isDetecting) {
        animationRef.current = requestAnimationFrame(detectFrame);
      }
    };

    detectFrame();
  }, [model, isDetecting, detect]);

  const stopDetection = useCallback(() => {
    setIsDetecting(false);
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  }, []);

  useEffect(() => {
    loadModel();
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [loadModel]);

  return {
    model,
    isLoading,
    isDetecting,
    trackedObjects,
    metrics,
    startDetection,
    stopDetection,
  };
};