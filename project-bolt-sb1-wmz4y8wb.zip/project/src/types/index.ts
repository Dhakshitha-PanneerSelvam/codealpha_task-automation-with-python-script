export interface DetectedObject {
  id: string;
  class: string;
  score: number;
  bbox: [number, number, number, number]; // [x, y, width, height]
  center: [number, number];
  timestamp: number;
}

export interface TrackedObject extends DetectedObject {
  trackId: string;
  trail: [number, number][];
  velocity: [number, number];
  lastSeen: number;
  confidence: number;
}

export interface Detection {
  bbox: [number, number, number, number];
  class: string;
  score: number;
}

export interface PerformanceMetrics {
  fps: number;
  detectionTime: number;
  trackingTime: number;
  objectCount: number;
  processingTime: number;
}